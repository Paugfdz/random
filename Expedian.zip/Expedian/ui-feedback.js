// UI feedback helpers for the Expedian demo (no alert/confirm/prompt).
(function() {
    'use strict';

    function ensureToastRoot() {
        let root = document.getElementById('expToastRoot');
        if (root) return root;

        root = document.createElement('div');
        root.id = 'expToastRoot';
        root.setAttribute('aria-live', 'polite');
        root.setAttribute('aria-atomic', 'true');
        root.className = 'fixed z-[1000] pointer-events-none top-4 right-4 left-4 sm:left-auto sm:w-[420px] space-y-2';
        document.body.appendChild(root);
        return root;
    }

    function toast(message, opts) {
        const options = opts || {};
        const type = options.type || 'info';
        const timeout = typeof options.timeout === 'number' ? options.timeout : 3200;

        const root = ensureToastRoot();
        const item = document.createElement('div');
        const base = 'pointer-events-auto w-full rounded-xl border shadow-md px-4 py-3 flex items-start gap-3 bg-white';
        const colors = {
            info: 'border-gray-200',
            success: 'border-green-200',
            warning: 'border-yellow-200',
            error: 'border-red-200'
        };
        const icon = {
            info: 'fa-circle-info text-blue-700',
            success: 'fa-circle-check text-green-700',
            warning: 'fa-triangle-exclamation text-yellow-700',
            error: 'fa-circle-xmark text-red-700'
        };

        item.className = base + ' ' + (colors[type] || colors.info);
        item.innerHTML =
            '<i class="fas ' + (icon[type] || icon.info) + ' mt-0.5"></i>' +
            '<div class="flex-1 text-sm text-gray-800">' + escapeHtml(String(message || '')) + '</div>' +
            '<button type="button" class="text-gray-500 hover:text-gray-900" aria-label="Cerrar">' +
                '<i class="fas fa-xmark"></i>' +
            '</button>';

        const closeBtn = item.querySelector('button');
        closeBtn.addEventListener('click', function() {
            item.remove();
        });

        root.appendChild(item);
        if (timeout > 0) {
            window.setTimeout(function() {
                if (item && item.parentNode) item.remove();
            }, timeout);
        }
    }

    function escapeHtml(s) {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function setBanner(container, message, opts) {
        if (!container) return;
        const options = opts || {};
        const type = options.type || 'info';
        const id = options.id || 'expInlineBanner';

        let el = container.querySelector('#' + id);
        if (!el) {
            el = document.createElement('div');
            el.id = id;
            el.setAttribute('role', 'alert');
            el.className = 'mb-4 rounded-xl border px-4 py-3 text-sm flex items-start gap-3';
            container.prepend(el);
        }

        const colors = {
            info: 'border-blue-200 bg-blue-50 text-blue-900',
            success: 'border-green-200 bg-green-50 text-green-900',
            warning: 'border-yellow-200 bg-yellow-50 text-yellow-900',
            error: 'border-red-200 bg-red-50 text-red-900'
        };
        const icon = {
            info: 'fa-circle-info',
            success: 'fa-circle-check',
            warning: 'fa-triangle-exclamation',
            error: 'fa-circle-xmark'
        };

        el.className = 'mb-4 rounded-xl border px-4 py-3 text-sm flex items-start gap-3 ' + (colors[type] || colors.info);
        el.innerHTML =
            '<i class="fas ' + (icon[type] || icon.info) + ' mt-0.5"></i>' +
            '<div class="flex-1">' + escapeHtml(String(message || '')) + '</div>' +
            '<button type="button" class="text-current/70 hover:text-current" aria-label="Cerrar">' +
                '<i class="fas fa-xmark"></i>' +
            '</button>';
        el.querySelector('button').addEventListener('click', function() { el.remove(); });
    }

    function clearBanner(container, id) {
        if (!container) return;
        const el = container.querySelector('#' + (id || 'expInlineBanner'));
        if (el) el.remove();
    }

    function ensureModalRoot() {
        let modal = document.getElementById('expModalRoot');
        if (modal) return modal;
        modal = document.createElement('div');
        modal.id = 'expModalRoot';
        modal.className = 'fixed inset-0 z-[1100] hidden';
        modal.innerHTML =
            '<div id="expModalOverlay" class="absolute inset-0 bg-black/40"></div>' +
            '<div class="relative max-w-xl mx-auto mt-10 sm:mt-16 px-4">' +
                '<div id="expModalCard" class="bg-white rounded-2xl shadow-xl overflow-hidden border">' +
                    '<div class="p-4 border-b flex items-start justify-between gap-3">' +
                        '<div>' +
                            '<div id="expModalTitle" class="text-lg font-semibold text-gray-900">-</div>' +
                            '<div id="expModalSub" class="text-sm text-gray-500 mt-0.5">-</div>' +
                        '</div>' +
                        '<button id="expModalClose" type="button" class="text-gray-500 hover:text-gray-900" aria-label="Cerrar">' +
                            '<i class="fas fa-xmark"></i>' +
                        '</button>' +
                    '</div>' +
                    '<div id="expModalBody" class="p-4"></div>' +
                '</div>' +
            '</div>';
        document.body.appendChild(modal);

        const overlay = modal.querySelector('#expModalOverlay');
        const close = modal.querySelector('#expModalClose');
        overlay.addEventListener('click', function() { hideModal(); });
        close.addEventListener('click', function() { hideModal(); });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && !modal.classList.contains('hidden')) hideModal();
        });
        return modal;
    }

    const dialogState = new WeakMap();

    function getFocusable(el) {
        if (!el) return [];
        const nodes = el.querySelectorAll(
            'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        return Array.from(nodes).filter(n => {
            const style = window.getComputedStyle(n);
            if (style.visibility === 'hidden' || style.display === 'none') return false;
            return true;
        });
    }

    function setBackgroundInert(modalEl, inertOn) {
        const children = Array.from(document.body.children);
        for (const child of children) {
            if (child === modalEl) continue;
            if (inertOn) {
                child.setAttribute('aria-hidden', 'true');
                if ('inert' in child) child.inert = true;
            } else {
                child.removeAttribute('aria-hidden');
                if ('inert' in child) child.inert = false;
            }
        }
    }

    function openDialog(modal, options) {
        const modalEl = typeof modal === 'string' ? document.getElementById(modal) : modal;
        if (!modalEl) return;

        const opts = options || {};
        const triggerEl = opts.trigger || document.activeElement;
        dialogState.set(modalEl, {
            trigger: triggerEl,
            keydown: null
        });

        // Show
        modalEl.classList.remove('hidden');
        modalEl.setAttribute('aria-modal', 'true');
        if (!modalEl.getAttribute('role')) modalEl.setAttribute('role', 'dialog');
        if (!modalEl.hasAttribute('tabindex')) modalEl.setAttribute('tabindex', '-1');

        // Inert background
        setBackgroundInert(modalEl, true);
        document.body.classList.add('overflow-hidden');

        // Focus
        let focusTarget = null;
        if (opts.initialFocusSelector) {
            focusTarget = modalEl.querySelector(opts.initialFocusSelector);
        }
        if (!focusTarget) {
            const focusables = getFocusable(modalEl);
            focusTarget = focusables[0] || modalEl;
        }
        if (focusTarget && focusTarget.focus) focusTarget.focus();

        // Trap focus + Esc
        const handler = function(e) {
            if (e.key === 'Escape') {
                if (opts.closeOnEscape === false) return;
                closeDialog(modalEl);
                return;
            }
            if (e.key !== 'Tab') return;
            const focusables = getFocusable(modalEl);
            if (!focusables.length) {
                e.preventDefault();
                return;
            }
            const first = focusables[0];
            const last = focusables[focusables.length - 1];
            const active = document.activeElement;

            if (e.shiftKey) {
                if (active === first || active === modalEl) {
                    e.preventDefault();
                    last.focus();
                }
            } else {
                if (active === last) {
                    e.preventDefault();
                    first.focus();
                }
            }
        };

        modalEl.addEventListener('keydown', handler);
        const st = dialogState.get(modalEl);
        if (st) st.keydown = handler;
    }

    function closeDialog(modal) {
        const modalEl = typeof modal === 'string' ? document.getElementById(modal) : modal;
        if (!modalEl) return;

        // Hide
        modalEl.classList.add('hidden');

        // Remove inert
        setBackgroundInert(modalEl, false);
        document.body.classList.remove('overflow-hidden');

        // Remove trap
        const st = dialogState.get(modalEl);
        if (st && st.keydown) modalEl.removeEventListener('keydown', st.keydown);

        // Restore focus
        const target = st && st.trigger ? st.trigger : null;
        if (target && target.focus) {
            try { target.focus(); } catch (e) { /* ignore */ }
        }
        dialogState.delete(modalEl);
    }

    function enhanceTabs(config) {
        const cfg = config || {};
        const tablist = cfg.tablistEl;
        const tabs = Array.from(cfg.tabs || []);
        const getPanel = cfg.getPanel;
        const activeClass = cfg.activeClass || 'active-tab';

        if (!tablist || !tabs.length || typeof getPanel !== 'function') return;
        tablist.setAttribute('role', 'tablist');

        function ensureId(el, prefix) {
            if (el.id) return el.id;
            el.id = prefix + '_' + Math.random().toString(16).slice(2);
            return el.id;
        }

        function sync() {
            for (const tab of tabs) {
                tab.setAttribute('role', 'tab');
                const tabId = ensureId(tab, 'expTab');
                const panel = getPanel(tab);
                if (panel) {
                    const panelId = ensureId(panel, 'expPanel');
                    tab.setAttribute('aria-controls', panelId);
                    panel.setAttribute('role', 'tabpanel');
                    panel.setAttribute('aria-labelledby', tabId);
                }

                const selected = tab.classList.contains(activeClass);
                tab.setAttribute('aria-selected', selected ? 'true' : 'false');
                tab.setAttribute('tabindex', selected ? '0' : '-1');
                if (panel) {
                    // If your UI uses the Tailwind 'hidden' class, reflect it in [hidden] for AT.
                    const isHidden = panel.classList.contains('hidden');
                    if (isHidden) panel.setAttribute('hidden', '');
                    else panel.removeAttribute('hidden');
                }
            }
        }

        tablist.addEventListener('keydown', function(e) {
            const keys = ['ArrowLeft', 'ArrowRight', 'Home', 'End'];
            if (!keys.includes(e.key)) return;
            const current = document.activeElement;
            const idx = tabs.indexOf(current);
            if (idx < 0) return;
            e.preventDefault();

            let nextIdx = idx;
            if (e.key === 'ArrowLeft') nextIdx = (idx - 1 + tabs.length) % tabs.length;
            if (e.key === 'ArrowRight') nextIdx = (idx + 1) % tabs.length;
            if (e.key === 'Home') nextIdx = 0;
            if (e.key === 'End') nextIdx = tabs.length - 1;

            const next = tabs[nextIdx];
            if (next && next.focus) next.focus();
            if (next && next.click) next.click();
            window.setTimeout(sync, 0);
        });

        tablist.addEventListener('click', function(e) {
            if (!e.target) return;
            const t = e.target.closest('[role="tab"], button, a');
            if (!t) return;
            window.setTimeout(sync, 0);
        }, true);

        sync();
        return { sync };
    }

    function showModal(title, sub, bodyHtml) {
        const modal = ensureModalRoot();
        modal.querySelector('#expModalTitle').textContent = String(title || '');
        modal.querySelector('#expModalSub').textContent = String(sub || '');
        modal.querySelector('#expModalBody').innerHTML = bodyHtml || '';
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
    }

    function hideModal() {
        const modal = document.getElementById('expModalRoot');
        if (!modal) return;
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
        // Clear body to detach handlers.
        const body = modal.querySelector('#expModalBody');
        if (body) body.innerHTML = '';
    }

    function confirmDialog(opts) {
        const o = opts || {};
        const title = o.title || 'Confirmar';
        const message = o.message || '';
        const confirmText = o.confirmText || 'Confirmar';
        const cancelText = o.cancelText || 'Cancelar';
        const danger = !!o.danger;

        return new Promise(function(resolve) {
            showModal(title, '',
                '<div class="text-sm text-gray-700">' + escapeHtml(message) + '</div>' +
                '<div class="mt-5 flex items-center justify-end gap-2">' +
                    '<button id="expConfirmCancel" type="button" class="px-4 py-2 rounded-xl border hover:bg-gray-50">' + escapeHtml(cancelText) + '</button>' +
                    '<button id="expConfirmOk" type="button" class="px-4 py-2 rounded-xl text-white ' + (danger ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700') + '">' + escapeHtml(confirmText) + '</button>' +
                '</div>'
            );

            const modal = ensureModalRoot();
            const ok = modal.querySelector('#expConfirmOk');
            const cancel = modal.querySelector('#expConfirmCancel');
            cancel.addEventListener('click', function() {
                hideModal();
                resolve(false);
            });
            ok.addEventListener('click', function() {
                hideModal();
                resolve(true);
            });
            // Focus the safest button first.
            cancel.focus();
        });
    }

    function openReminderModal(opts) {
        const o = opts || {};
        const patientName = o.patientName || 'Paciente';
        const phone = o.phone || '';
        const message = o.message || '';
        const title = o.title || 'Enviar recordatorio';

        return new Promise(function(resolve) {
            const phoneLine = phone ? ('<div class="text-xs text-gray-500 mt-1">Telefono: <span class="font-medium text-gray-700">' + escapeHtml(phone) + '</span></div>') :
                '<div class="text-xs text-red-700 mt-1">Falta telefono del paciente.</div>';

            showModal(title, patientName,
                '<div class="text-sm text-gray-700">Elige el canal. Puedes copiar el mensaje.</div>' +
                phoneLine +
                '<div class="mt-4 border rounded-xl bg-gray-50 p-3">' +
                    '<div class="text-xs text-gray-500">Mensaje</div>' +
                    '<div class="text-sm text-gray-800 mt-1 whitespace-pre-wrap">' + escapeHtml(message) + '</div>' +
                '</div>' +
                '<div class="mt-5 flex flex-col sm:flex-row gap-2 sm:justify-end">' +
                    '<button id="expRemWhats" type="button" class="px-4 py-2 rounded-xl border hover:bg-gray-50 flex items-center justify-center gap-2">' +
                        '<i class="fab fa-whatsapp"></i> WhatsApp' +
                    '</button>' +
                    '<button id="expRemSms" type="button" class="px-4 py-2 rounded-xl border hover:bg-gray-50 flex items-center justify-center gap-2">' +
                        '<i class="fas fa-comment-dots"></i> SMS' +
                    '</button>' +
                    '<button id="expRemCopy" type="button" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center gap-2">' +
                        '<i class="fas fa-copy"></i> Copiar' +
                    '</button>' +
                '</div>'
            );

            const modal = ensureModalRoot();
            const bWhats = modal.querySelector('#expRemWhats');
            const bSms = modal.querySelector('#expRemSms');
            const bCopy = modal.querySelector('#expRemCopy');

            function done(kind) {
                hideModal();
                resolve(kind);
            }

            bCopy.addEventListener('click', async function() {
                try {
                    await navigator.clipboard.writeText(String(message || ''));
                    toast('Mensaje copiado al portapapeles.', { type: 'success' });
                } catch (e) {
                    toast('No se pudo copiar. Selecciona y copia manualmente.', { type: 'warning', timeout: 4500 });
                }
                done('copy');
            });

            bWhats.addEventListener('click', function() {
                if (!phone) {
                    toast('Falta telefono del paciente.', { type: 'error' });
                    return;
                }
                const digits = String(phone).replace(/\D/g, '');
                const url = 'https://wa.me/' + digits + '?text=' + encodeURIComponent(String(message || ''));
                window.open(url, '_blank', 'noopener');
                done('whatsapp');
            });

            bSms.addEventListener('click', function() {
                if (!phone) {
                    toast('Falta telefono del paciente.', { type: 'error' });
                    return;
                }
                const digits = String(phone).replace(/\D/g, '');
                const url = 'sms:' + digits + '?&body=' + encodeURIComponent(String(message || ''));
                window.location.href = url;
                done('sms');
            });

            // Primary action focus
            bCopy.focus();
        });
    }

    function ensureFieldErrorEl(input) {
        if (!input || !input.parentElement) return null;
        let el = input.parentElement.querySelector('.exp-field-error');
        if (el) return el;
        el = document.createElement('div');
        el.className = 'exp-field-error text-xs text-red-700 mt-1';
        el.id = (input.id ? (input.id + '_err') : ('err_' + Math.random().toString(16).slice(2)));
        input.parentElement.appendChild(el);
        return el;
    }

    function setFieldError(input, message) {
        if (!input) return;
        const el = ensureFieldErrorEl(input);
        if (!el) return;
        el.textContent = String(message || '');
        input.setAttribute('aria-invalid', 'true');
        input.setAttribute('aria-describedby', el.id);
        input.classList.add('border-red-300');
    }

    function clearFieldError(input) {
        if (!input) return;
        input.removeAttribute('aria-invalid');
        input.classList.remove('border-red-300');
        const id = input.getAttribute('aria-describedby');
        if (id) {
            const el = document.getElementById(id);
            if (el && el.classList.contains('exp-field-error')) el.textContent = '';
        }
    }

    function clearFormErrors(form) {
        if (!form) return;
        clearBanner(form);
        form.querySelectorAll('[aria-invalid="true"]').forEach(function(el) {
            clearFieldError(el);
        });
        form.querySelectorAll('.exp-field-error').forEach(function(el) {
            el.textContent = '';
        });
    }

    function focusFirstError(form) {
        if (!form) return;
        const first = form.querySelector('[aria-invalid="true"]');
        if (first && typeof first.focus === 'function') first.focus();
    }

    window.ExpedianUI = {
        toast,
        setBanner,
        clearBanner,
        confirm: confirmDialog,
        openReminderModal,
        setFieldError,
        clearFieldError,
        clearFormErrors,
        focusFirstError
        ,
        openDialog,
        closeDialog,
        enhanceTabs
    };
})();
