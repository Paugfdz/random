// Shared auth + user helpers for the Expedian demo (localStorage only).
// Keep this file framework-free so every HTML page can include it.
(function() {
    'use strict';

    const KEYS = {
        SESSION: 'medisys_session_v1',
        USERS: 'medisys_users_v1',
        SETTINGS_GLOBAL: 'medisys_settings_v1',
        PROFILE_GLOBAL: 'medisys_doctor_profile_v1',

        // Legacy / earlier drafts
        USERS_LEGACY: 'expedian_users_v1',
        SESSION_LEGACY: 'expedian_session_v1'
    };

    function safeJsonParse(value, fallback) {
        try {
            const parsed = JSON.parse(value);
            return (parsed === null || typeof parsed === 'undefined') ? fallback : parsed;
        } catch (e) {
            return fallback;
        }
    }

    function normalizeEmail(email) {
        return String(email || '').trim().toLowerCase();
    }

    function newId() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
        return 'u_' + Date.now() + '_' + Math.random().toString(16).slice(2);
    }

    function userSettingsKey(userId) {
        return 'medisys_settings_' + String(userId) + '_v1';
    }

    function userProfileKey(userId) {
        return 'medisys_doctor_profile_' + String(userId) + '_v1';
    }

    function loadUsersRaw(key) {
        const items = safeJsonParse(localStorage.getItem(key), []);
        return Array.isArray(items) ? items : [];
    }

    function saveUsers(items) {
        localStorage.setItem(KEYS.USERS, JSON.stringify(items || []));
    }

    function loadUsers() {
        // Prefer the new key.
        let users = loadUsersRaw(KEYS.USERS);
        if (!users.length) {
            // If the older admin panel key exists, migrate it.
            const legacy = loadUsersRaw(KEYS.USERS_LEGACY);
            if (legacy.length) {
                saveUsers(legacy);
                users = legacy;
            }
        }
        return users;
    }

    function getSession() {
        // If an earlier build wrote a session under a different key, keep it usable.
        const s = safeJsonParse(localStorage.getItem(KEYS.SESSION), null);
        if (s && (s.userId || s.email)) return s;
        const legacy = safeJsonParse(localStorage.getItem(KEYS.SESSION_LEGACY), null);
        if (legacy && (legacy.userId || legacy.email)) return legacy;
        return null;
    }

    function setSession(session) {
        localStorage.setItem(KEYS.SESSION, JSON.stringify(session));
        // Clean up old session key to avoid split-brain.
        localStorage.removeItem(KEYS.SESSION_LEGACY);
    }

    function clearSession() {
        localStorage.removeItem(KEYS.SESSION);
        localStorage.removeItem(KEYS.SESSION_LEGACY);
    }

    function findUserByEmail(email) {
        const e = normalizeEmail(email);
        return loadUsers().find(u => normalizeEmail(u.email) === e) || null;
    }

    function findUserById(id) {
        return loadUsers().find(u => u && u.id === id) || null;
    }

    function ensureSessionHasUserId() {
        const s = getSession();
        if (!s || s.userId || !s.email) return s;
        const u = findUserByEmail(s.email);
        if (!u) return s;
        const next = { ...s, userId: u.id, email: normalizeEmail(u.email) };
        setSession(next);
        return next;
    }

    function migrateLegacySingleAccountToUsers() {
        // Older versions store a single account in medisys_settings_v1 + medisys_doctor_profile_v1.
        // If there is no users list yet, convert that account into the first (Admin) user.
        const existingUsers = loadUsers();
        if (existingUsers.length) return existingUsers;

        const settings = safeJsonParse(localStorage.getItem(KEYS.SETTINGS_GLOBAL), null);
        if (!settings || !settings.auth || !settings.auth.passwordHash || !settings.account || !settings.account.email) {
            return existingUsers;
        }

        const profile = safeJsonParse(localStorage.getItem(KEYS.PROFILE_GLOBAL), null);
        const email = normalizeEmail(settings.account.email);
        const name = String(settings.account.name || (profile && profile.name) || '').trim() || email;

        const id = newId();
        const roleFromSettings = (settings.permissions && settings.permissions.role) ? String(settings.permissions.role) : 'Doctor';
        const role = roleFromSettings === 'Admin' ? 'Admin' : 'Admin'; // Bootstrap: make the first legacy account Admin.

        const user = {
            id,
            name,
            email,
            role,
            status: 'active',
            subscription: {
                plan: (settings.billing && settings.billing.plan) ? String(settings.billing.plan) : 'Pro',
                cycle: (settings.billing && settings.billing.cycle) ? String(settings.billing.cycle) : 'monthly'
            },
            permissions: settings.permissions || {},
            modules: settings.modules || {},
            auth: { passwordHash: String(settings.auth.passwordHash) },
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        saveUsers([user]);
        // Store per-user copies so we can swap users without losing data.
        localStorage.setItem(userSettingsKey(id), JSON.stringify(settings));
        if (profile && typeof profile === 'object') {
            localStorage.setItem(userProfileKey(id), JSON.stringify(profile));
        }
        return [user];
    }

    function getCurrentUser() {
        migrateLegacySingleAccountToUsers();
        const s = ensureSessionHasUserId();
        if (!s) return null;
        if (s.userId) return findUserById(s.userId);
        if (s.email) return findUserByEmail(s.email);
        return null;
    }

    function loadSettingsForUserId(userId) {
        const fromUser = safeJsonParse(localStorage.getItem(userSettingsKey(userId)), null);
        if (fromUser && typeof fromUser === 'object') return fromUser;
        const global = safeJsonParse(localStorage.getItem(KEYS.SETTINGS_GLOBAL), null);
        return (global && typeof global === 'object') ? global : null;
    }

    function loadProfileForUserId(userId) {
        const fromUser = safeJsonParse(localStorage.getItem(userProfileKey(userId)), null);
        if (fromUser && typeof fromUser === 'object') return fromUser;
        const global = safeJsonParse(localStorage.getItem(KEYS.PROFILE_GLOBAL), null);
        return (global && typeof global === 'object') ? global : null;
    }

    function syncGlobalsForUser(userId) {
        if (!userId) return { settings: null, profile: null };
        const settings = loadSettingsForUserId(userId);
        const profile = loadProfileForUserId(userId);
        if (settings) localStorage.setItem(KEYS.SETTINGS_GLOBAL, JSON.stringify(settings));
        if (profile) localStorage.setItem(KEYS.PROFILE_GLOBAL, JSON.stringify(profile));
        return { settings, profile };
    }

    function saveCurrentUserSettings(settings) {
        const u = getCurrentUser();
        if (!u || !u.id) return;
        localStorage.setItem(userSettingsKey(u.id), JSON.stringify(settings || {}));

        const users = loadUsers();
        const idx = users.findIndex(x => x && x.id === u.id);
        if (idx >= 0) {
            const next = { ...users[idx] };
            if (settings && typeof settings === 'object') {
                if (settings.permissions) next.permissions = settings.permissions;
                if (settings.modules) next.modules = settings.modules;
                if (settings.billing) next.subscription = { plan: settings.billing.plan, cycle: settings.billing.cycle };
                if (settings.account && settings.account.name) next.name = String(settings.account.name);
                if (settings.account && settings.account.email) next.email = normalizeEmail(settings.account.email);
            }
            next.updatedAt = new Date().toISOString();
            users[idx] = next;
            saveUsers(users);
        }
    }

    function saveCurrentUserProfile(profile) {
        const u = getCurrentUser();
        if (!u || !u.id) return;
        localStorage.setItem(userProfileKey(u.id), JSON.stringify(profile || {}));

        const users = loadUsers();
        const idx = users.findIndex(x => x && x.id === u.id);
        if (idx >= 0) {
            const next = { ...users[idx] };
            if (profile && typeof profile === 'object') {
                if (profile.name) next.name = String(profile.name);
                if (profile.email) next.email = normalizeEmail(profile.email);
            }
            next.updatedAt = new Date().toISOString();
            users[idx] = next;
            saveUsers(users);
        }
    }

    function applyModulesVisibility(modules) {
        const m = modules && typeof modules === 'object' ? modules : {};
        document.querySelectorAll('[data-module]').forEach(el => {
            const key = el.getAttribute('data-module');
            if (key && m[key] === false) el.classList.add('hidden');
        });
    }

    function bindLogoutLink(linkId) {
        const link = document.getElementById(linkId);
        if (!link) return;
        link.addEventListener('click', function(e) {
            e.preventDefault();
            clearSession();
            window.location.href = 'login.html';
        });
    }

    function bindLogoutButton(buttonId) {
        const btn = document.getElementById(buttonId);
        if (!btn) return;
        btn.addEventListener('click', function() {
            clearSession();
            window.location.href = 'login.html';
        });
    }

    function initSidebarA11y(options) {
        const opts = options || {};
        const sidebarSelector = opts.sidebarSelector || '.sidebar';
        const toggleId = opts.toggleId || 'toggleSidebar';
        const linkSelector = opts.linkSelector || (sidebarSelector + ' nav a');

        const sidebar = document.querySelector(sidebarSelector);
        const toggle = document.getElementById(toggleId);

        ensureMobileNavUi({ sidebarSelector });

        if (sidebar && toggle) {
            if (!sidebar.id) sidebar.id = 'expSidebar';
            toggle.setAttribute('aria-controls', sidebar.id);
            if (isMobileViewport()) {
                toggle.setAttribute('aria-expanded', sidebar.classList.contains('exp-mobile-open') ? 'true' : 'false');
            } else {
                toggle.setAttribute('aria-expanded', sidebar.classList.contains('collapsed') ? 'false' : 'true');
            }
        }

        document.querySelectorAll(linkSelector).forEach(function(a) {
            // Ensure an accessible name even when collapsed.
            if (!a.getAttribute('aria-label')) {
                const t = (a.querySelector('.sidebar-text') && a.querySelector('.sidebar-text').textContent)
                    ? a.querySelector('.sidebar-text').textContent.trim()
                    : a.textContent.trim();
                if (t) a.setAttribute('aria-label', t);
            }

            if (sidebar && isMobileViewport() && !a.dataset.expMobileNavCloseBound) {
                a.dataset.expMobileNavCloseBound = '1';
                a.addEventListener('click', function() {
                    closeMobileNav(sidebar);
                });
            }
        });
    }

    function toggleSidebar(options) {
        const opts = options || {};
        const sidebarSelector = opts.sidebarSelector || '.sidebar';
        const sidebar = document.querySelector(sidebarSelector);
        if (!sidebar) return;

        if (isMobileViewport()) {
            toggleMobileNav(sidebar);
        } else {
            sidebar.classList.toggle('collapsed');
        }
        initSidebarA11y(opts);
    }

    function isMobileViewport() {
        try {
            return window.matchMedia && window.matchMedia('(max-width: 640px)').matches;
        } catch (e) {
            return false;
        }
    }

    function inPreviewMode() {
        try {
            const params = new URLSearchParams(window.location.search);
            return params.get('preview') === '1';
        } catch (e) {
            return false;
        }
    }

    function closeMobileNav(sidebarEl) {
        const sidebar = sidebarEl;
        if (!sidebar) return;
        sidebar.classList.remove('exp-mobile-open');
        document.body.classList.remove('exp-mobile-nav-open');
        const btn = document.getElementById('expMobileMenuBtn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
    }

    function openMobileNav(sidebarEl) {
        const sidebar = sidebarEl;
        if (!sidebar) return;
        sidebar.classList.remove('collapsed');
        sidebar.classList.add('exp-mobile-open');
        document.body.classList.add('exp-mobile-nav-open');
        const btn = document.getElementById('expMobileMenuBtn');
        if (btn) btn.setAttribute('aria-expanded', 'true');
    }

    function toggleMobileNav(sidebarEl) {
        const sidebar = sidebarEl;
        if (!sidebar) return;
        if (sidebar.classList.contains('exp-mobile-open')) closeMobileNav(sidebar);
        else openMobileNav(sidebar);
    }

    function ensureMobileNavUi(options) {
        if (inPreviewMode()) return;
        const opts = options || {};
        const sidebarSelector = opts.sidebarSelector || '.sidebar';
        const sidebar = document.querySelector(sidebarSelector);
        if (!sidebar) return;

        // Overlay
        let overlay = document.getElementById('expMobileNavOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'expMobileNavOverlay';
            overlay.className = 'exp-mobile-nav-overlay';
            overlay.addEventListener('click', function() {
                closeMobileNav(sidebar);
            });
            document.body.appendChild(overlay);
        }

        // Global hamburger button
        let btn = document.getElementById('expMobileMenuBtn');
        if (!btn) {
            btn = document.createElement('button');
            btn.id = 'expMobileMenuBtn';
            btn.type = 'button';
            btn.className = 'exp-mobile-menu-btn';
            btn.setAttribute('aria-label', 'Abrir menú');
            btn.innerHTML = '<i class="fas fa-bars" aria-hidden="true"></i>';
            btn.addEventListener('click', function() {
                toggleMobileNav(sidebar);
            });
            document.body.appendChild(btn);
        }

        if (!sidebar.id) sidebar.id = 'expSidebar';
        btn.setAttribute('aria-controls', sidebar.id);
        btn.setAttribute('aria-expanded', sidebar.classList.contains('exp-mobile-open') ? 'true' : 'false');

        // Default: closed on mobile.
        if (isMobileViewport()) {
            sidebar.classList.remove('collapsed');
            closeMobileNav(sidebar);
        }

        // Auto-close when resizing up to desktop.
        if (!ensureMobileNavUi._boundResize) {
            ensureMobileNavUi._boundResize = true;
            window.addEventListener('resize', function() {
                const sb = document.querySelector(sidebarSelector);
                if (!sb) return;
                if (isMobileViewport()) {
                    sb.classList.remove('collapsed');
                    closeMobileNav(sb);
                    return;
                }
                closeMobileNav(sb);
            });
        }
    }

    function applyDoctorProfileSidebar(profile, ids) {
        const p = profile && typeof profile === 'object' ? profile : null;
        if (!p) return;
        const avatarId = (ids && ids.avatarId) ? ids.avatarId : 'doctorAvatar';
        const nameId = (ids && ids.nameId) ? ids.nameId : 'doctorName';
        const specialtyId = (ids && ids.specialtyId) ? ids.specialtyId : 'doctorSpecialty';

        if (p.avatar) {
            const img = document.getElementById(avatarId);
            if (img) img.src = p.avatar;
        }
        if (p.name) {
            const el = document.getElementById(nameId);
            if (el) el.textContent = p.name;
        }
        if (p.specialty) {
            const el = document.getElementById(specialtyId);
            if (el) el.textContent = p.specialty;
        }
    }

    function applyActiveNav(options) {
        const opts = options || {};
        const selector = opts.selector || '.exp-nav-link';
        const current = (window.location.pathname.split('/').pop() || '').trim() || 'index.html';

        const alias = {
            'nuevo-paciente.html': 'index.html',
            'mi-perfil.html': 'mi-perfil.html'
        };
        const effectiveCurrent = alias[current] || current;

        document.querySelectorAll(selector).forEach(function(a) {
            const href = a.getAttribute('href');
            if (!href) return;
            if (href.startsWith('#') || href.startsWith('http:') || href.startsWith('https:') || href.startsWith('mailto:')) return;
            const target = href.split('#')[0].split('?')[0];
            if (target === effectiveCurrent) a.setAttribute('aria-current', 'page');
            else a.removeAttribute('aria-current');
        });
    }

    function getUiNumber(key, fallback) {
        try {
            const raw = localStorage.getItem(String(key));
            if (raw == null) return fallback;
            const n = Number(raw);
            return Number.isFinite(n) ? n : fallback;
        } catch (e) {
            return fallback;
        }
    }

    function setUiNumber(key, value) {
        try {
            localStorage.setItem(String(key), String(value));
        } catch (e) {
            // ignore
        }
    }

    function requireAuth(options) {
        const params = new URLSearchParams(window.location.search);
        if (params.get('preview') === '1') {
            // Public preview mode for marketing embeds (no session required).
            return { session: null, user: null, settings: null, profile: null, modules: null, preview: true };
        }
        migrateLegacySingleAccountToUsers();
        const nextPart = window.location.pathname.split('/').pop() + window.location.search + window.location.hash;
        const opts = options || {};
        const next = (typeof opts.next === 'string' && opts.next) ? opts.next : nextPart;

        let s = getSession();
        if (!s || (!s.userId && !s.email)) {
            window.location.href = 'login.html?next=' + encodeURIComponent(next);
            return { session: null, user: null, settings: null, profile: null, modules: null };
        }
        s = ensureSessionHasUserId();
        const u = getCurrentUser();
        if (!u || u.status !== 'active') {
            clearSession();
            window.location.href = 'login.html?next=' + encodeURIComponent(next);
            return { session: null, user: null, settings: null, profile: null, modules: null };
        }
        if (opts.requireRole && u.role !== opts.requireRole) {
            window.location.href = 'login.html?next=' + encodeURIComponent(next);
            return { session: s, user: u, settings: null, profile: null, modules: null };
        }

        const synced = syncGlobalsForUser(u.id);
        const settings = synced.settings;
        const modules = (u.modules && typeof u.modules === 'object' && Object.keys(u.modules).length)
            ? u.modules
            : (settings && settings.modules ? settings.modules : {});

        if (opts.module && modules && modules[opts.module] === false) {
            // If the current page is disabled, bounce to dashboard.
            window.location.href = 'dashboard.html';
            return { session: s, user: u, settings, profile: synced.profile, modules };
        }

        return { session: s, user: u, settings, profile: synced.profile, modules };
    }

    window.ExpedianAuth = {
        KEYS,
        normalizeEmail,
        newId,
        safeJsonParse,
        loadUsers,
        saveUsers,
        getSession,
        setSession,
        clearSession,
        getCurrentUser,
        findUserByEmail,
        findUserById,
        userSettingsKey,
        userProfileKey,
        loadSettingsForUserId,
        loadProfileForUserId,
        syncGlobalsForUser,
        saveCurrentUserSettings,
        saveCurrentUserProfile,
        requireAuth,
        applyModulesVisibility,
        bindLogoutLink,
        bindLogoutButton,
        applyDoctorProfileSidebar,
        applyActiveNav,
        initSidebarA11y,
        toggleSidebar,
        getUiNumber,
        setUiNumber,
        migrateLegacySingleAccountToUsers
    };
})();
